function  [par]=ParSet(deblur_class,nSig)
   
    par.nSig      = nSig;
    par.SearchWin = 30;                       % Non-local patch searching window  
    par.patsize   = 7;                        % Patch size
    par.patnum    = 40;                       % Initial Non-local Patch number  
    
    par.alpha    = 100000;
    par.beta     = 100000; 
    
 switch deblur_class
      
   case 1  % Gaussian Kernel
                 
    if  par.nSig == 5;     
        par.w = 2*sqrt(2*par.patnum)*par.nSig^2;  
        par.lamada   = 0.05;
        par.tol=1E-5; 
    elseif  par.nSig == 7;    
        par.w = 2*sqrt(2*par.patnum)*par.nSig^2;  
        par.lamada   = 0.1;
        par.tol=1E-5; 
    elseif par.nSig == 10;       
        par.w = 2*sqrt(2*par.patnum)*par.nSig^2;  
        par.lamada   = 0.16 ;
        par.tol=1E-5;
    elseif par.nSig == 15;     
        par.w = 2*sqrt(2*par.patnum)*par.nSig^2;  
        par.lamada   = 0.35 ;%0.35
        par.tol=1E-5;
    elseif par.nSig == 20;   
        par.w = 2*sqrt(2*par.patnum)*par.nSig^2;  
        par.lamada   = 0.60 ;%
        par.tol=1E-5;
    else
        par.w = 2*sqrt(2*par.patnum)*par.nSig^2;  
        par.lamada   = 1.0;
        par.tol=1E-5;
    end
    
   case 2  % Uniform Kernel
       
    if  par.nSig == 5;  
        par.w = 2*sqrt(2*par.patnum)*par.nSig^2;  
        par.lamada   = 0.03;
        par.tol=1E-4; 
    elseif par.nSig == 7; 
        par.w = 2*sqrt(2*par.patnum)*par.nSig^2;  
        par.lamada   = 0.06;
        par.tol=1E-4;
    elseif par.nSig == 10; 
        par.w = 2*sqrt(2*par.patnum)*par.nSig^2;  
        par.lamada   = 0.1;
        par.tol=1E-4;
    elseif par.nSig == 15;  
        par.w = 2*sqrt(2*par.patnum)*par.nSig^2;  
        par.lamada   = 0.25;
        par.tol=1E-4;
    elseif par.nSig == 20;  
        par.w = 2*sqrt(2*par.patnum)*par.nSig^2;  
        par.lamada   = 0.30;
        par.tol=1E-4;
    else
        par.w = 2*sqrt(2*par.patnum)*par.nSig^2;  
        par.lamada   = 0.60;
        par.tol=1E-4;
    end
    
 end
 
 par.Iter     = 100;                        % Total iter number

 par.step      =4;                    
   
end

 


 


 
     




