function [RX_Img,iter] = PARM_deblur(N_Img,H,Par) 
% Copyright June. 20, 2022, Dr.Yan Hui-Yin
% email: yanhuiyin@xynu.edu.cn

[Height, Width] = size(N_Img);    
ColSize  = Par.patsize;                                                        
g        = N_Img;
             
Vxtol = 1;
u_img =  inv(H'*H+Par.lamada)*(H'*N_Img+Par.lamada*N_Img);
X_Blocks =  ImtoCol(u_img,ColSize);

[Ori_patchblocks] =  ImtoCol(u_img,ColSize);
[NL_mat] = BlockMatch(Ori_patchblocks,Par,Height,Width);

X_Imgk = zeros(size(u_img));


iter = 1;

while (((iter<=Par.Iter)&&(Vxtol>=1e-4))) 
    
   u_Blocks = ImtoCol(u_img,ColSize);
   [X_Blocks,Sum_RXblocks,W]  = Patch_Estimation(NL_mat,u_Blocks,X_Blocks,Par,Height,Width);   % Estimate all the patches
   RX_Img = Sum_RXblocks./W;
  
   Wg = W.*g; 
   b  = H'*Wg+Par.lamada*Sum_RXblocks+u_img/Par.alpha; b=b(:);
   
   lamada = Par.lamada;alpha=Par.alpha;
   [Vu_Img,flag0] = cgs(@(x)Afun(x,H,W,lamada,alpha,Height,Width), b, Par.tol, 100,[],[]);
   u_img = reshape(Vu_Img,Height,Width);

   Vxtol = norm(RX_Img(:)-X_Imgk(:))/norm(RX_Img(:));
   X_Imgk = RX_Img;
   iter=iter+1;
   
end
 

function  y  =  Afun(f,H,W,lamada,alpha,Height,Width)
f = reshape(f,Height,Width);
Hf= H*f; 
WHf=W.*Hf;
alpha_u=ones(size(W))/alpha;
y = H'*WHf+lamada*W.*f+alpha_u;  
y = y(:);
return;

