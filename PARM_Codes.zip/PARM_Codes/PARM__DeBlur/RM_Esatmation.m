
function  [X] = RM_Esatmation(Y,NSig)
    [U,SigmaY,V] =   svd(full(Y),'econ'); 
  
    TempC   = sqrt(2*NSig);
    ind     = find (SigmaY>TempC);
    svp     = length(ind);
    SigmaX       = SigmaY(ind);    
    X       = U(:,1:svp)*diag(SigmaX)*V(:,1:svp)';    
end
