 %clc; 
 clear; close all;

 a = imread('camera.tif'); 
% a = imread('Castle.tif');% Imread image
  
  [M, N,layer] = size(a);
  
  if     layer==1   
         I=double(a);       
  else  
         x_yuv    =       rgb2ycbcr(a); 
         I        =       double(x_yuv(:,:,1));       
         X_re     =       zeros(size(x_yuv));       
         X_re(:,:,2)     =       x_yuv(:,:,2);        
         X_re(:,:,3)     =       x_yuv(:,:,3);   
  end

  deblur_class = 2; % Blur kernel, '1' for Gaussian Kernel and '2' for Uniform Kernel
  
   switch deblur_class  
     
        case 1 
          psf    =  fspecial('Gaussian', [9,9],2);
        case 2 
          psf    =  ones(9); psf=psf./sum(psf(:));
          
   end
  
  H  =  BlurMatrix(psf, size(I));      %Blur matrix
  blur_im = H * I;                        
   
  randn('state',10000);  
  OrgSigma =5; % Noise level
  
  N_Img = blur_im + OrgSigma*randn(size(I)) ;  % Generate the observed image

  Par= ParSet(deblur_class,OrgSigma);  

  tic;[X_Img,it] = PARM_deblur(N_Img,H,Par);time=toc; %PARM image restoration

  if  layer==3 
    
    X_re(:,:,1)  =  X_Img;
    
    RX_img=ycbcr2rgb(uint8(X_re));
    
  else 
      
    RX_img=X_Img;
    
  end

  R_Psnr  = csnr(I,X_Img,0,0);
  ssim    = cal_ssim(I,X_Img,0,0);

  fprintf('Sigma = %d, PSNR = %.2f dB, SSIM=%.4f, CPU Time = %.2f seconds,Iter = %d \n\n',OrgSigma, R_Psnr, ssim, time,it);

  figure;  imshow(uint8(RX_img));



