function  [par]=ParSet(inpaint_class)
     
    par.SearchWin = 30;                       % Non-local patch searching window  
    par.patsize   = 7;                        % Patch size
    par.patnum    = 40;                       % Initial Non-local Patch number  
    
    par.alpha    = 100000;
    par.beta     = 100000; 
    
 switch inpaint_class
      
   case 1  %Text pixels missing 
    
          par.w = 50*sqrt(2*par.patnum);  
          par.lamada   = 0.28;
     
   case 2  %40 pixels missing 
       
         par.w = 50*sqrt(2*par.patnum);  
         par.lamada   = 0.28;

   case 3  %50 pixels missing 

        par.w = 50*sqrt(2*par.patnum);  
        par.lamada   = 0.28;
 
   case 4  %60 pixels missing 
       
         par.w = 50*sqrt(2*par.patnum);  
         par.lamada   = 0.28;
       

   case 5  %70 pixels missing 
    
          par.w = 50*sqrt(2*par.patnum);  
          par.lamada   = 0.28;
                       
 end
 
 par.Iter     = 600;                        % Total iter number

 par.step      =4;                    
   
end

 


 


 
     




