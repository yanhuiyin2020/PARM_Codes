 function  Z  =  ImtoCol(g,ColSize)

Z = zeros(ColSize*ColSize, (size(g,1)-ColSize+1)*(size(g,2)-ColSize+1));                 
k = 0;

for i  = 1:ColSize
    for j  = 1:ColSize
        k      =  k+1;
        temp   =  g(i:end-ColSize+i,j:end-ColSize+j);
        Z(k,:) =  temp(:)';
    end
end
