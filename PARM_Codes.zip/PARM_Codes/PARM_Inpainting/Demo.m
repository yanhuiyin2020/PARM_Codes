%clc; 
clear; close all;

  % a = imread('boat.png');    
  a = imread('Mickey.tif');



[M, N,layer] = size(a);
 
if       layer==1   
         I=double(a);       
else  
         x_yuv    =       rgb2ycbcr(a); 
         I        =       double(x_yuv(:,:,1));       
         X_re     =       zeros(size(x_yuv));       
         X_re(:,:,2)     =       x_yuv(:,:,2);        
         X_re(:,:,3)     =       x_yuv(:,:,3);   
end


%% Generate the observed image.

inpaint_class=1;
  
 switch inpaint_class
      
      case 1  %Text mask pixels missing;
                Ms = floor(double(imread('block_text.bmp'))/255);ratio=1;
                MS=Ms(1:256,21:276);
                H=ones(M,N);
                H(M/2-127:M/2+128,N/2-127:N/2+128)=MS;   
     
      case 2  %random mask 40% pixels missing;
                rand('seed',0);ratio=0.6;
                H = double(rand(M,N) > (1-ratio));
      
      case 3  %random mask 50% pixels missing;
                rand('seed',0);ratio=0.5;
                H = double(rand(M,N) > (1-ratio));
                
      case 4  %random mask 60% pixels missing;
                rand('seed',0);ratio=0.4;
                H = double(rand(M,N) > (1-ratio));  
                
      case 5  %random mask 70% pixels missing;
                rand('seed',0);ratio=0.3;
                H = double(rand(M,N) > (1-ratio));         
 end
  
randn('state',10000);  
   
N_Img =  H .* I+5*randn(M,N);  % Generate degraded image

Par= ParSet(inpaint_class);  

tic;[X_Img,it] = PARM_inpainting(N_Img,H,Par);time=toc; % PARM image restoration


if  layer==3
       
    X_re(:,:,1)  =  X_Img;    
    
    RX_img=ycbcr2rgb(uint8(X_re));
    
else 
    
    RX_img=X_Img;
    
end
  

R_Psnr  = csnr(I,X_Img,0,0);
ssim    = cal_ssim(I,X_Img,0,0);

fprintf('Pixels Missing = %d%%, PSNR = %.2f dB, SSIM=%.4f, CPU Time = %.2f seconds,iter = %d \n\n',100*(1-ratio), R_Psnr, ssim, time,it);

figure;  imshow(uint8(RX_img));







