function  [NLBLK]  =  BlockMatch(X, par,Height, Width)
PatchNO     = par.patnum;          ColSize = par.patsize; SW = par.SearchWin;
s           = par.step;          


Idx      =   (1:(Height - ColSize + 1)*(Width  - ColSize + 1));
Idx      =   reshape(Idx, Height - ColSize + 1, Width  - ColSize + 1);

RowL=Height-ColSize+1;
RowIdx	=   [1:s:RowL];
RowIdx	=   [RowIdx RowIdx(end)+1:RowL];
ClumL   =   Width-ColSize+1;
ClumIdx	=   [1:s:ClumL];
ClumIdx	=   [ClumIdx ClumIdx(end)+1:ClumL];

NLBLK       =  zeros(PatchNO,length(ClumIdx)*length(RowIdx));

k        = 0; 
for  i  = 1:length(RowIdx)
    for  j  =  1:length(ClumIdx)
        
        k=k+1;       
        top         = max(RowIdx(i)-SW, 1);
        button      = min(RowIdx(i)+SW, Height - ColSize + 1);        
        left        = max(ClumIdx(j)-SW, 1);
        right       = min(ClumIdx(j)+SW, Width  - ColSize + 1);     
        NL_Idx      = Idx(top:button, left:right);
        NL_Idx      = NL_Idx(:);
        
        Patch       = X(:,(ClumIdx(j)-1)*(Height-ColSize+1) +RowIdx(i));
        Neighbors   = X(:,NL_Idx);   
        Dist        = sum((repmat(Patch,1,size(Neighbors,2))-Neighbors).^2);    
       
        [v, idx]    = sort(Dist);
        NLBLK(:,k)  = NL_Idx(idx(1:PatchNO));  
        
    end
end