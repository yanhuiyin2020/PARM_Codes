function [New_XBlocks,RX_img,W] = Patch_Estimation(NL_mat,Rx_Blocks,X_Blocks,Par,Height,Width)

PatchNO     = Par.patnum; 
ColSize     = Par.patsize;

W_Blocks    = zeros(size(Rx_Blocks));
New_XBlocks = zeros(size(Rx_Blocks));
 
k = 0;

for  i  = 1:length(NL_mat)   
        k  = k + 1;   
        par_X = Par.lamada*Par.beta+1;
        X_patMat = X_Blocks(:,NL_mat(:,k))/par_X;
        Estpar = Par.lamada*Par.beta/par_X;
        Ori_EstMat  =  Estpar*Rx_Blocks(:,NL_mat(:,k)); 
        Ori_EstMat  =  Ori_EstMat+X_patMat;
        Lam = Par.beta*Par.w/(Par.beta*Par.lamada+1);
        EX_patMat 	= RM_Esatmation(Ori_EstMat,Lam);    % RM Estimation   
       
        New_XBlocks(:,NL_mat(:,k)) =  New_XBlocks(:,NL_mat(:,k))+ EX_patMat;
        W_Blocks(:,NL_mat(:,k))    =  W_Blocks(:,NL_mat(:,k))+ones(ColSize*ColSize,PatchNO);
        
end

[RX_img,W]=ColtoIm(New_XBlocks,W_Blocks,ColSize,Height,Width);
