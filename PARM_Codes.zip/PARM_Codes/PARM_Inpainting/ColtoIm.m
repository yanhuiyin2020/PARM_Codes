function  [Y,W]  =  ColtoIm(ImPatch, WeightPatch, ColSize, ImageH, ImageW)
    
ImRow   =   ImageH-ColSize+1;
ImCol   =   ImageW-ColSize+1;
OffR =   0:ImRow-1;
OffC =   0:ImCol-1;    

Y  	=  zeros(ImageH,ImageW);
W 	=  zeros(ImageH,ImageW);
k       =   0;
   
for i  = 1:ColSize
    for j  = 1:ColSize
        k    =  k+1;
        Y(OffR+i,OffC+j)  =  Y(OffR+i,OffC+j) + reshape(ImPatch(k,:)', [ImRow ImCol]);
        W(OffR+i,OffC+j)  =  W(OffR+i,OffC+j) + reshape(WeightPatch(k,:)', [ImRow ImCol]);
    end    
end


