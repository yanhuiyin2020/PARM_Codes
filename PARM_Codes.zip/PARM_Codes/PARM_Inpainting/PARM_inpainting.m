function [RX_Img,iter] = PARM_inpainting(N_Img,H,Par) 
% Copyright June. 20, 2022, Dr.Yan Hui-Yin
% email: yanhuiyin@xynu.edu.cn

[Height, Width] = size(N_Img);    
ColSize  = Par.patsize;                                                        
g        = N_Img;           
Vxtol = 1;
u_img = Inter_Initial(N_Img,~H);
X_Blocks =  ImtoCol(u_img,ColSize);

[Ori_patchblocks] =  ImtoCol(u_img,ColSize);
[NL_mat] = BlockMatch(Ori_patchblocks,Par,Height,Width);

X_Imgk = zeros(size(u_img));

iter = 1;

while (((iter<=Par.Iter)&&(Vxtol>=5e-5))) 
    
   Ru_Blocks = ImtoCol(u_img,ColSize);
   [X_Blocks,Sum_RXblocks,W]  = Patch_Estimation(NL_mat,Ru_Blocks,X_Blocks,Par,Height,Width);   % Estimate all the patches
   RX_Img = Sum_RXblocks./W;
  
   Wg = W.*g; 
   b  = H.*Wg+Par.lamada*Sum_RXblocks+u_img/Par.alpha; 
   
   alpha=1/Par.alpha;
  
   u_img = b./(H.*W+Par.lamada*W+alpha*ones(size(H)));
   
   Vxtol = norm(RX_Img(:)-X_Imgk(:))/norm(RX_Img(:)); 
   
   X_Imgk = RX_Img;
     
   iter=iter+1;
   
end
 